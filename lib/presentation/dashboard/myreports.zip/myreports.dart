import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:yoga_centre_app/presentation/util/appcolor.dart';

class Myreports extends StatefulWidget {
  @override
  _MyReportsState createState() => _MyReportsState();
}

class _MyReportsState extends State<Myreports> {
  List<dynamic> _reports = [];
  List<String> _course = [];
  bool _isLoading = true;
  String? _selectedMonth;
  String? _selectedCoursename;

  final List<String> _months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];

  @override
  void initState() {
    super.initState();
    _fetchCourses();
  }

  Future<void> _fetchCourses() async {
    final String url = 'http://192.168.29.121:3000/YogaApp/getcoursemaster';

    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status']) {
          setState(() {
            _course = (data['message'] as List)
                .map((course) => course['coursename'] as String)
                .toList();
          });
        } else {
          print('Failed to load courses: ${data['message']}');
        }
      } else {
        throw Exception('Failed to load courses');
      }
    } catch (error) {
      print('Error fetching courses: $error');
    }
  }

  Future<void> _fetchFilteredReports({String? course, String? month}) async {
    final String url = 'http://192.168.29.121:3000/YogaApp/myscore';

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'createdBy': '1',
          'courseId': course,
          'date': month != null ? _months.indexOf(month) + 1 : null,
        }),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status']) {
          Map<String, int> occurrencesMap = {};
          for (var report in data['message']) {
            String date = report['date'];
            int occurrence = report['occurance'];

            occurrencesMap[date] = (occurrencesMap[date] ?? 0) + occurrence;
          }

          setState(() {
         
            _reports = occurrencesMap.entries.map((entry) {
              return {
                'date': entry.key,
                'occurance': entry.value,
              };
            }).toList();
            _isLoading = false;
          });
        } else {
          setState(() {
            _reports = [];
            _isLoading = false;
          });
          print('Failed to load reports: ${data['message']}');
        }
      } else {
        throw Exception('Failed to load reports');
      }
    } catch (error) {
      setState(() {
        _isLoading = false;
      });
      print('Error fetching reports: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Reports'),
      ),
      body: Column(
        children: [
         
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        hint: Text('Select Course'),
                        value: _selectedCoursename,
                        isExpanded: true,
                        onChanged: (String? newValue) {
                          setState(() {
                            _selectedCoursename = newValue;
                          });
                        },
                        items: _course.map<DropdownMenuItem<String>>((String course) {
                          return DropdownMenuItem<String>(
                            value: course,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(course),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        hint: Text('Select Month'),
                        value: _selectedMonth,
                        isExpanded: true,
                        onChanged: (String? newValue) {
                          setState(() {
                            _selectedMonth = newValue;
                          });
                        },
                        items: _months.map<DropdownMenuItem<String>>((String month) {
                          return DropdownMenuItem<String>(
                            value: month,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(month),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.filter_list),
                  color: AppColor.primary,
                  onPressed: () {
                    setState(() {
                      _isLoading = true;
                    });
                    _fetchFilteredReports(course: _selectedCoursename, month: _selectedMonth);
                  },
                ),
              ],
            ),
          ),
          Expanded(
            child: _isLoading
                ? Center(child: CircularProgressIndicator())
                : _reports.isEmpty
                    ? Center(child: Text('No reports found.'))
                    : ListView.builder(
                        itemCount: _reports.length,
                        itemBuilder: (context, index) {
                          final report = _reports[index];
                          final date = report['date'];
                          return Card(
                            margin: EdgeInsets.all(16.0),
                            elevation: 4,
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Date: $date',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    'Occurrence: ${report['occurance']}',
                                    style: TextStyle(
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
