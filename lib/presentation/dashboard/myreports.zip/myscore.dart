import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'dart:convert';
import 'package:yoga_centre_app/presentation/util/appcolor.dart'; 

class Myscore extends StatefulWidget {
  @override
  _MyScorePageState createState() => _MyScorePageState();
}

class _MyScorePageState extends State<Myscore> {
  DateTime _selectedDate = DateTime.now();
  String? _selectedCoursename;
  final TextEditingController _occurranceController = TextEditingController();

  List<String> _courseList = [];

  @override
  void initState() {
    super.initState();
    _fetchCourseList(); 
  }

  Future<void> _fetchCourseList() async {
    try {
      final response = await http.get(
        Uri.parse('http://192.168.29.121:3000/YogaApp/getcoursemaster'),
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);

        if (responseData['status'] == true) {
          setState(() {
            _courseList = List<String>.from(
              responseData['message'].map((course) => course['coursename']),
            );
          });
        } else {
          // Handle failure to fetch course data
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Failed to fetch course list: ${responseData['message']}'),
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to load courses. Please try again.'),
          ),
        );
      }
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('An error occurred while fetching courses.'),
        ),
      );
    }
  }

  void _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate)
      setState(() {
        _selectedDate = picked;
      });
  }

  Future<void> _submitData() async {
    String occurrance = _occurranceController.text;

    if (_selectedCoursename == null || occurrance.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please select a course and enter an occurrance.'),
        ),
      );
      return;
    }

    final String url = 'http://192.168.29.121:3000/YogaApp/addmyscore';
    final Map<String, dynamic> data = {
      'date': DateFormat('yyyy-MM-dd').format(_selectedDate),
      'coursename': _selectedCoursename,
      'occurance': occurrance,
      'remarks': 'Great progress!', 
      'createdBy': '1',
      'courseid': '2',
    };

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: json.encode(data),
      );

      final responseData = json.decode(response.body);

      if (response.statusCode == 200) {
        if (responseData['status'] == true) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Submitted successfully!'),
            ),
          );

          _occurranceController.clear();
          setState(() {
            _selectedCoursename = null;
            _selectedDate = DateTime.now();
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Failed to submit: ${responseData['message']}'),
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to submit. Please try again.'),
          ),
        );
      }
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('An error occurred. Please check your internet connection.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Score'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              InputDecorator(
                decoration: InputDecoration(
                  labelText: 'Select Date',
                  border: OutlineInputBorder(),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        'Selected Date: ${DateFormat('yyyy-MM-dd').format(_selectedDate)}',
                        style: TextStyle(fontSize: 16),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.calendar_today),
                      onPressed: () => _selectDate(context),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _selectedCoursename,
                decoration: InputDecoration(
                  labelText: 'Select Course Name',
                  border: OutlineInputBorder(),
                ),
                isExpanded: true,
                items: _courseList.map((String course) {
                  return DropdownMenuItem<String>(
                    value: course,
                    child: Text(
                      course,
                      overflow: TextOverflow.ellipsis,
                    ),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedCoursename = newValue;
                  });
                },
              ),
              SizedBox(height: 16),
              TextField(
                controller: _occurranceController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Occurrance',
                ),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 32),
              ElevatedButton(
                onPressed: _submitData,
                child: Text('Submit', style: TextStyle(color: Colors.white)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColor.primary, // Ensure this matches your theme
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
